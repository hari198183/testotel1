package com.philipstarritt.fitness.domain;

public enum Coach {
    PHILIP,
    PETER
}

package com.philipstarritt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnSpringGraphqlApplicationTests {

    @Test
    void contextLoads() {
    }

}
